


 CLUSTAL 2.1 Multiple Sequence Alignments


Sequence format is Pearson
Sequence 1: Equus_przewalskii_mammal         1423 aa
Sequence 2: Homo_sapiens_mammal              1423 aa
Sequence 3: Lemmus_lemmus_mammal             1423 aa
Sequence 4: Bufotes_viridis_amphibian        1423 aa
Sequence 5: Leptosomus_discolor_bird         1423 aa
Sequence 6: Danio_rerio_fish                 1423 aa
Sequence 7: Passer_montanus_bird             1423 aa
Sequence 8: Numida_meleagris_bird            1423 aa
Sequence 9: Phyllostomus_discolor_mammal     1423 aa
Sequence 10: Patagioenas_fasciata_bird        1423 aa
Sequence 11: Apis_cerana_insect               1423 aa
Sequence 12: Nasonia_vitripennis_insect       1423 aa
Sequence 13: Papilio_polytes_insect           1423 aa
Sequence 14: Lucilia_cuprina_insect           1423 aa
Sequence 15: Chrysoperla_carnea_insect        1423 aa
Sequence 16: Blattella_germanica_insect       1423 aa
Sequence 17: Meleagris_gallopavo_bird         1423 aa
Sequence 18: Plutella_xylostella_insect       1423 aa
Sequence 19: Willisornis_vidua_bird           1423 aa

           Equus_przewalskii_mammal 
           Homo_sapiens_mammal 
           Lemmus_lemmus_mammal 
           Bufotes_viridis_amphibian 
           Leptosomus_discolor_bird 
           Danio_rerio_fish 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Homo_sapiens_mammal 
           Lemmus_lemmus_mammal 
           Bufotes_viridis_amphibian 
           Leptosomus_discolor_bird 
           Danio_rerio_fish 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Lemmus_lemmus_mammal 
           Bufotes_viridis_amphibian 
           Leptosomus_discolor_bird 
           Danio_rerio_fish 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Bufotes_viridis_amphibian 
           Leptosomus_discolor_bird 
           Danio_rerio_fish 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Leptosomus_discolor_bird 
           Danio_rerio_fish 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Danio_rerio_fish 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Passer_montanus_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Numida_meleagris_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Phyllostomus_discolor_mammal 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Patagioenas_fasciata_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Apis_cerana_insect 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Nasonia_vitripennis_insect 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Papilio_polytes_insect 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Lucilia_cuprina_insect 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Chrysoperla_carnea_insect 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Blattella_germanica_insect 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Meleagris_gallopavo_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Plutella_xylostella_insect 
           Willisornis_vidua_bird 
           Willisornis_vidua_bird 
perc identity file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/mafft/interactive/20260423/0056/mafft-I20260423-005601-0116-53347206-p1m.sqr.pim]

Phylogenetic tree file created:   [/nfs/public/rw/es/projects/wp-jdispatcher/sources/prod-hl/jobs/mafft/interactive/20260423/0056/mafft-I20260423-005601-0116-53347206-p1m.sqr.ph]

